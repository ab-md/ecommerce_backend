import authMessages from "./auth.messages.js";
import { checkVerificaitionCodeService, registerService, sendVerificationCodeService } from "./auth.service.js";

const register = async (req, res, next) => {
    try {
        const user = await registerService(req.body);
        return res.status(201).json({
            statusCode: res.statusCode,
            message: authMessages.registerSuccess,
            // data: user
        });
    } catch (error) {
        next(error);
    }
}

const sendVerificationCode = async (req, res, next) => {
    try {
        await sendVerificationCodeService(req.body);
        return res.status(200).json({
            statusCode: res.statusCode,
            message: authMessages.sendCode,
        })
    } catch (error) {
        next(error);
    }
}

const checkVerificationCode = async (req, res, next) => {
    try {
        await checkVerificaitionCodeService(req.body);
        return res.status(200).json({
            statusCod: res.statusCode,
            message: authMessages.activated
        });
    } catch (error) {
        next(error);
    }
}

export {
    register,
    sendVerificationCode,
    checkVerificationCode,
}