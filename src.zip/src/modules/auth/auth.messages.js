const authMessages = {
    notRegistered: "You are not registered yet.Please create an account",
    codeNotExpired: "Verification code has not expired yet",
    codeExpired: "Verification code has expired",
    codeNotMatch: "Entered code is invalid",
    existingEmail: "This email is already registered",
    serverError: "Something went wrong",
    registerSuccess: "Registered successfully",
    sendCode: "Verification code sent successfully",
    activated: "Your account activated successfully"
}

export default authMessages;